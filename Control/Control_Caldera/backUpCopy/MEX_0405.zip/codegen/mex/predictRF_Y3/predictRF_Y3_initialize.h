/*
 * predictRF_Y3_initialize.h
 *
 * Code generation for function 'predictRF_Y3_initialize'
 *
 */

#ifndef PREDICTRF_Y3_INITIALIZE_H
#define PREDICTRF_Y3_INITIALIZE_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "predictRF_Y3_types.h"

/* Function Declarations */
extern void predictRF_Y3_initialize(void);

#endif

/* End of code generation (predictRF_Y3_initialize.h) */
