/*
 * _coder_predictRF_Y3_info.h
 *
 * Code generation for function '_coder_predictRF_Y3_info'
 *
 */

#ifndef _CODER_PREDICTRF_Y3_INFO_H
#define _CODER_PREDICTRF_Y3_INFO_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "predictRF_Y3_types.h"

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif

/* End of code generation (_coder_predictRF_Y3_info.h) */
